package org.koitharu.kotatsu.parsers.model

public enum class Demographic {
	SHOUNEN,
	SHOUJO,
	SEINEN,
	JOSEI,
	KODOMO,
	NONE,
}
