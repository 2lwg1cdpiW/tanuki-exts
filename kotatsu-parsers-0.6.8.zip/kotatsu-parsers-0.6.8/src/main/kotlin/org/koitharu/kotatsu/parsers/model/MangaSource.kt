package org.koitharu.kotatsu.parsers.model

public interface MangaSource {

	public val name: String
}
