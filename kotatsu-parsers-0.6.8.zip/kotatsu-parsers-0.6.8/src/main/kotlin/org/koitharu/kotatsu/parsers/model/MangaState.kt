package org.koitharu.kotatsu.parsers.model

public enum class MangaState {
	ONGOING, FINISHED, ABANDONED, PAUSED, UPCOMING, RESTRICTED
}
